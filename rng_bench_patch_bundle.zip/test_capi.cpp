#include <iostream>
#include <cstdint>
#include <chrono>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif

typedef void* (*fn_new)(uint64_t, int, int);
typedef void  (*fn_free)(void*);
typedef uint64_t (*fn_next_u64)(void*);
typedef double (*fn_next_double)(void*);
typedef void  (*fn_seed)(void*, uint64_t);
typedef void  (*fn_jump)(void*, uint64_t, uint64_t);

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: test_capi <path_to_lib> [algo_id=0] [bitwidth=1]\n";
        return 1;
    }

    const char* libpath = argv[1];
    int algo_id = (argc > 2) ? atoi(argv[2]) : 0;
    int bw = (argc > 3) ? atoi(argv[3]) : 1;

#ifdef _WIN32
    HMODULE lib = LoadLibraryA(libpath);
    if (!lib) { std::cerr << "Failed to load DLL.\n"; return 1; }
    auto getfn = [&](const char* n){ return (void*)GetProcAddress(lib, n); };
#else
    void* lib = dlopen(libpath, RTLD_LAZY);
    if (!lib) { std::cerr << "Failed to load: " << dlerror() << "\n"; return 1; }
    auto getfn = [&](const char* n){ return dlsym(lib, n); };
#endif

    fn_new new_fn = (fn_new)getfn("universal_rng_new");
    fn_free free_fn = (fn_free)getfn("universal_rng_free");
    fn_next_u64 next_fn = (fn_next_u64)getfn("universal_rng_next_u64");
    fn_next_double nextd_fn = (fn_next_double)getfn("universal_rng_next_double");

    if (!new_fn || !next_fn) {
        std::cerr << "Missing required symbols in library.\n";
        return 2;
    }

    void* rng = new_fn(12345, algo_id, bw);
    if (!rng) { std::cerr << "Failed to create RNG handle.\n"; return 3; }

    const int N = 1000000;
    uint64_t sum = 0;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < N; ++i) sum += next_fn(rng);
    auto end = std::chrono::high_resolution_clock::now();
    double sec = std::chrono::duration<double>(end - start).count();

    std::cout << "Generated " << N << " numbers in " << sec << " s (" << (N / sec / 1e6) << " M/s)\n";
    std::cout << "Example double: " << nextd_fn(rng) << "\n";

    free_fn(rng);
#ifdef _WIN32
    FreeLibrary(lib);
#else
    dlclose(lib);
#endif
    return 0;
}
